#define CATCH_CONFIG_MAIN\n#include "catch.hpp"\n
