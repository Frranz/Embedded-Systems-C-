#include "OptParser.cpp"


int main(int argc, char *argv[]) {
	CmdLineOptParser parser;

	bool parseSuccess = parser.Parse(argc, argv);
	printf("Parse returned %s\n", (parseSuccess) ? "true": "false");

	return 0;
}
