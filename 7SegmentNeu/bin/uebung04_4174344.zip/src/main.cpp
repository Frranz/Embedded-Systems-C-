#include "../include/7Segment.h"

int main() {
    constexpr MultiDigit md{1,2};
    return 0;
}
