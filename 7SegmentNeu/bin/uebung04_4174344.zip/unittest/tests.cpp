#include "catch.hpp"
#include "../include/7Segment.h"
